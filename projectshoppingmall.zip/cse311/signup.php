<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
<link rel="stylesheet" type="text/css" href="signup.css">

</head>
<body class="bg">

<div class="start">
	<form action="index.php" method="Post" >
		<h1> Sign Up or Registration </h1>

	<input type="text" name="fname" class="txtbox" placeholder="Enter First Name" /><br/><br/>
	<input type="text" name="lname" class="txtbox" placeholder="Enter Last Name" /><br/><br/>
	<input type="email" name="email" class="txtbox" placeholder="Enter Email ID" /><br/><br/>
	<input type="dateofbirth" name="dateofbirth" class="txtbox" placeholder="Enter Date of Birth" /><br/><br/>
	<input type="pnumber" name="pnumber" class="txtbox" placeholder="Enter Phone Number" /><br/><br/>
	<input type="tdnumber" name="tdnumber" class="txtbox" placeholder="Enter Trade Licence Number" /><br/><br/>
	<input type="password" name="password" class="txtbox" placeholder="Enter Password" /><br/><br/>
	<input type="cpassword" name="cpassword" class="txtbox" placeholder="Confirm Password" /><br/><br/>
	<input type="submit" name="signup" class="button" value="signup" ><br><br/>


    

</form>
	</div>
</body> 
	</html>

