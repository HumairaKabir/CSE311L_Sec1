<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	
	<link rel="stylesheet" type="text/css" href="login.css">

</head>
<body class="bg">
	<div class="start">

<form action="" method="post" >
<center>
	
 <h1> Login </h1>
<img src="admin.png" class="img"></center>

<input type="email" name="email" class="txtbox" placeholder="Enter email"><br/><br/>

<input type="password" name="password" class="txtbox" placeholder="Enter password"><br/><br/>
	
<input type="SUBMIT" name="login" class="button" value="LOGIN" ><br><br/>
<input type="submit" name="login" class="button" value="BACK" ><br><br/>


	</form>
</div>
		</body>
</html>




<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'shoppingmall');

if(isset($_POST['login']))
{
	$email = $_POST['email'];
	$password = $_POST['password'];

	$query = "select * form 'signup' WHERE email='$email' and password ='$password'";
	 $query_run = mysqli_query($connection,$query);

	 if(mysqli_fetch_array($query_run)>0)
	 {
	 	echo '<script type="text/javascript"> alert("Logged In Successfull") </script>';
	 	//header('location:mainpage.php');
	 }
	 else
	 {
	 	echo '<script type="text/javascript"> alert("Log In Failed") </script>';
	 }
}

?>
















