<?php 
session_start();

?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'parts.php' ?>
</head>
<body class=image>

<div class= "container center-div shadow">	
	<div class = "heading text-center text-uppercase text-black mb-5"> Admin Dashboard
	</div>
		<a href="logout.php" class = "btn btn-danger mb-3">  
		Logout</a>
</div>



</body>
</html>